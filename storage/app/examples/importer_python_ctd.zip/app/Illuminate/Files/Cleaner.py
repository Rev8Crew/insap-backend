import shutil
import os


class Cleaner:
    def __init__(self, dir_name):
        self.dir = dir_name

    def clear(self, re_make_dir: bool = True):
        if os.path.exists(self.dir):
            shutil.rmtree(self.dir)

        if re_make_dir:
            return os.mkdir(self.dir, mode=755)

        return True
