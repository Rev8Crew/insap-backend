################################
########### Imports ##############
import os
import json
import argparse

from shutil import copyfile

from app import importer
from app.Illuminate.Files.Cleaner import Cleaner

from app.Illuminate.Helpers.ParamStorage import ParamStorage

#############################

IMPORTER_VERSION = '1.0'
IMPORTER_NAME = 'CTD importer'


def read_data_from_json(path: str):
    try:
        with open(path, encoding='utf-8') as json_file:
            return json.load(json_file)
    except EnvironmentError:
        return []


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--test', type=bool, default=False)

    args = parser.parse_args()

    if args.test:
        exit(0)

    absolute_path = os.path.dirname(os.path.abspath(__file__))

    data_path = os.path.join(absolute_path, "data")
    files_path = os.path.join(data_path, "files")

    result_path = os.path.join(absolute_path, "result")
    result_files_path = os.path.join(result_path, "files")

    # Clear dirs
    Cleaner(result_path).clear(True)
    Cleaner(result_files_path).clear(True)

    # Get data
    params = read_data_from_json(os.path.join(data_path, "params.json"))
    files = read_data_from_json(os.path.join(data_path, "files.json"))
    data = read_data_from_json(os.path.join(data_path, "data.json"))

    storage = ParamStorage(
        files_path,
        params,
        files,
        data
    )

    result = importer.process(storage)

    # Write to data.json
    with open(os.path.join(result_path, "data.json"), 'w', encoding='utf-8') as file:
        json.dump(result, file, ensure_ascii=False, indent=4)

    # Write params.json
    with open(os.path.join(result_path, "params.json"), 'w', encoding='utf-8') as file:
        json.dump(storage.get_params(), file, ensure_ascii=False, indent=4)

    # Write params.json
    with open(os.path.join(result_path, "files.json"), 'w', encoding='utf-8') as file:
        json.dump(storage.get_files(), file, ensure_ascii=False, indent=4)

    # Copy all files from data/files to result/files
    for file_name in os.listdir(files_path):
        print(os.path.join(files_path, file_name))
        print(os.path.join(result_files_path, file_name))
        copyfile(os.path.join(files_path, file_name), os.path.join(result_files_path, file_name))

    exit(0)
