<?php
$options = getopt('', [ 'test::']);
$test = $options['test'] ?? null;

if ($test) {
    // OK
    return 0;
}