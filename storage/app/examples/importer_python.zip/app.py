import argparse

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--test', type=bool, default=False)

    args = parser.parse_args()

    if args.test:
        exit(0)

    exit(0)
