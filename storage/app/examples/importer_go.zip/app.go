package main

import (
	"os"

	"github.com/DavidGamba/go-getoptions"
)

func main() {
	opt := getoptions.New()
	opt.Bool("test", false, opt.Alias("h", "?"))

	opt.Parse(os.Args[1:])

	if opt.Called("test") {
		// OK
		os.Exit(0)
	}

	os.Exit(0)
}
